5. Future Directions
====================

pyRXP is mature and unlikely to change further.  At the time of writing in 2013,
*libxml2/libxslt* and the very popular *lxml* package which use them, seem to
have "picked up the mantle of"cornered the market" for full features XML 
processing in Python; and the standard library now has *cElementTree* so can
do lightweight parsing quickly.

We expect to be using it for several years to come and will attempt to support
any bugs found.


ReportLab
 Thornton House
 Thornton Road
 Wimbledon
 London, UK SW19 4NG
