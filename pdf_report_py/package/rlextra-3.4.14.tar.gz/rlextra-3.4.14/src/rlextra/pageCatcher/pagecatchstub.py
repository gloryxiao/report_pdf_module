from rlextra.pageCatcher.pageCatcher import *

if __name__=="__main__": #NO RUNTESTS
    scriptInterp()
    