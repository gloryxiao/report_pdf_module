#Copyright ReportLab Europe Ltd. 2000-2017
#see license.txt for license details
#history www.reportlab.co.uk/rl-cgi/viewcvs.cgi/rlextra/thirdparty/__init__.py
__version__='3.3.0'
# The thirdparty package exists to allow us to have other packages in a standard location
# eg we can do
#from rlextra.thirdparty.rlextra.thirdparty import xlrd
