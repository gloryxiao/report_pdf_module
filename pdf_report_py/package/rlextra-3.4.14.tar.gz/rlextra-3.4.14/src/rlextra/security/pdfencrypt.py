#copyright ReportLab Europe Limited. 2000-2016
#see license.txt for license details
__version__='3.3.0'
__doc__="""Script stub for pdfencryption.

This can be shipped in plain mode outside of any encrypted archives.
"""
from reportlab.lib.pdfencrypt import *

if __name__ == '__main__':
    main()
