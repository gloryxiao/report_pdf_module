Example of xml to rml translation.

To run the example, execute:

    $ python play2rml.py

This will generate two new files in shakespeare.1.10.xml/:

    + j_ceasar.rml
    + j_ceasar.pdf
